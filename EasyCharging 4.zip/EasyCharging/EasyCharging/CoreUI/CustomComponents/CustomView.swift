//import SwiftUI
//
//public protocol View {
//
//    associatedtype Body : View
//
//    var body: Self.Body { get }
//}
//
//protocol CustomView: View {
//
//    func applyTheme() -> Theme
//}
//
//extension CustomView {
//    //Default implementation that I won't have to rewrite for each view.
//}
