import Foundation

public extension Notification.Name {
    static let themeToggled = Notification.Name("themeToggled")
}
