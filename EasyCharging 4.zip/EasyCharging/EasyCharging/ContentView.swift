import SwiftUI
import FirebaseCore

struct ContentView: View {
    
    @EnvironmentObject var viewModel: AuthViewModel
    @State private var coordinator = NavigationCoordinator()
    
    init() {
        FirebaseApp.configure()
        ThemeType.toggled(ThemeType.light)()
    }
    
    let themePub = NotificationCenter.default
        .publisher(for: .themeToggled)
    
    var body: some View {
        NavigationStack(path: $coordinator.paths) {
            if(viewModel.isAuthenticated) {
                coordinator.navigate(to: .mainView, data: nil) 
                    .navigationBarBackButtonHidden(true)
                    .navigationDestination(for: Screens.self) { screen in
                        coordinator.navigate(to: screen, data: nil)
                    }
            }else {
                coordinator.navigate(to: .welcomeView, data: nil)
                    .navigationBarBackButtonHidden(true)
                    .navigationDestination(for: Screens.self) { screen in
                        coordinator.navigate(to: screen, data: nil)
                    }
            }
        }.environment(coordinator)
    }
}

