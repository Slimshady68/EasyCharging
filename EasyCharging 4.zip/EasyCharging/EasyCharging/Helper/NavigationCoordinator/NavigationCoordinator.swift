



import Foundation
import SwiftUI
import Observation

enum Screens: Hashable {
    case mainView
    case loginView
    case welcomeView
    case registerView
    case homeView
    case favoriteView
    case favDetailView
    case filterView
    case profileView
    case rentYourCharger
    case mapView
    case myStation
    case stationDetail(CustomStation)
    case reportForm(CustomStation)
    case useStationView(CustomStation)
    case waitingStationView(CustomStation)
    case verifyStationView(CustomStation)
    case stationPaymentView(CustomStation, PaymentModel)
}

@Observable
class NavigationCoordinator {
    var paths = NavigationPath()

    // We will add this item to navigate method to pass
    @ViewBuilder
    func navigate(to screen: Screens, data: Any?)  -> some View {
        switch screen {
        case .mainView:
                MainView().navigationBarBackButtonHidden(true)
        case .loginView:
            LoginView().navigationBarBackButtonHidden(true)
        case .welcomeView:
            WelcomeView().navigationBarBackButtonHidden(true)
        case .registerView:
            RegisterView().navigationBarBackButtonHidden(true)
        case .homeView:
            Home().navigationBarBackButtonHidden(true)
        case .favoriteView:
            FavoriteView().navigationBarTitleDisplayMode(.inline)
        case .favDetailView:
              FavDetailView().navigationBarBackButtonHidden(false)
        case .filterView:
            FilterView()
        case .profileView:
            UserProfileView().navigationBarBackButtonHidden(true)
        case .rentYourCharger:
            RentYourCharger().navigationBarBackButtonHidden(false)
        case .mapView:
            MapView().navigationBarBackButtonHidden(true)
        case .myStation:
            MyStationView().navigationBarBackButtonHidden(false)
        case .stationDetail(let station):
            StationDetailView(station: station).navigationBarBackButtonHidden(false)
        case .reportForm(let station):
            ReportFormView(station: station).navigationBarBackButtonHidden(false)
        case .useStationView(let station):
            UseStationView(station: station).navigationBarBackButtonHidden(false)
        case .waitingStationView(let station):
            UseStationWaitingView(station: station).navigationBarBackButtonHidden(false)
        case .verifyStationView(let station):
            UseStationVerificationView(station: station).navigationBarBackButtonHidden(false)
        case .stationPaymentView(let station, let paymentModel):
            PaymentView(station: station, paymentModel: paymentModel).navigationBarBackButtonHidden(false)
        }

    }

    // add screen
    func push(_ screen: Screens) {
        paths.append(screen)
    }

    // remove last screen
    func pop() {
        paths.removeLast()
    }

    // go to root screen
    func popToRoot() {
        paths.removeLast(paths.count)
    }
    func toHome() {
        paths.removeLast(5)
    }
    
    
}

