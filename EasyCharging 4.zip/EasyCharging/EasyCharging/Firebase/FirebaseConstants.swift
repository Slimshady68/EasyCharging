import Foundation

struct FirebaseConstants {
    static let email = "email"
    static let uid = "uid"
    static let users = "users"
    
    static let pathUserCollection = "users";
}
