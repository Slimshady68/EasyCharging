import SwiftUI
import FirebaseFirestore
import FirebaseAuth
import MapKit

struct StationDetailView: View {
    
    @StateObject var manager = LocationManager()
    @State private var isShowingAlert = false
    @State private var alertMessage = ""
    
    var station: CustomStation
    @State private var distance: Int = 0
    @State private var myStation = [CustomStation]()
    @State private var isFavorite = false
    
    @Environment(NavigationCoordinator.self) var coordinator: NavigationCoordinator
    
    func findDistance() {
        let currentCenter = manager.myRegion.center
        let currentLocation = CLLocation(latitude: currentCenter.latitude, longitude: currentCenter.longitude)
        
        let stationLocation = CLLocation(latitude: station.latitude, longitude: station.longitude)
        let distanceInMeters = currentLocation.distance(from: stationLocation)
        let distanceInMiles = (distanceInMeters * 0.000621371).rounded() // Convert meters to miles and round to nearest whole number
        distance = Int(distanceInMiles)
    }
    
    var body: some View {
        VStack{
            ScrollView {
                VStack(spacing: 8) {
                    addressSection
                    detailsSection
                    connectorsSection
                    actionButtons
                    useStationButton
                }
            }
            .navigationTitle(station.address)
            .alert(isPresented: $isShowingAlert) {
                Alert(title: Text(""), message: Text(alertMessage), dismissButton: .default(Text("OK")))
            }
            .onAppear {
                findDistance()
                getMyStations()
            }
        }
    }
    
    private var addressSection: some View {
        VStack {
            HStack {
                Text(station.address)
                Spacer()
                Button(action: openMapsApp) {
                    Image(systemName: "location")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 24, height: 24)
                }
            }
        }
        .padding()
        .frame(maxWidth: .infinity, minHeight: 10)
        .overlay(
            RoundedRectangle(cornerRadius: 10)
                .stroke(Color.gray.opacity(0.4), lineWidth: 1)
        )
        .padding([.leading, .trailing])
        .padding(.top, 8)
    }
    
    private var detailsSection: some View {
        VStack(spacing: 8) {
            SectionTitle(title: "Access")
            SectionDetail(detail: "Public")
            
            SectionTitle(title: "Station Status")
            SectionDetail(detail: "Functional")
            
            SectionTitle(title: "Distance")
            SectionDetail(detail: "\(distance) miles")
            
            SectionTitle(title: "Phone")
            SectionDetail(detail: station.phone)
            
            SectionTitle(title: "Access Time")
            SectionDetail(detail: "24 Hours daily")
            
            SectionTitle(title: "Pricing")
            SectionDetail(detail: "$\(station.rate)/Hour")
        }
        .padding(.top, 8)
        .padding(.bottom)
        .overlay(
            RoundedRectangle(cornerRadius: 10)
                .stroke(Color.gray.opacity(0.4), lineWidth: 1)
        )
        .padding([.leading, .trailing])
        .padding(.top, 8)
    }
    
    private var connectorsSection: some View {
        VStack {
            SectionTitle(title: "Connectors")
            SectionDetail(detail: "\(station.charger) \(station.level)")
        }
        .padding(.top, 8)
        .padding(.bottom)
        .overlay(
            RoundedRectangle(cornerRadius: 10)
                .stroke(Color.gray.opacity(0.4), lineWidth: 1)
        )
        .padding([.leading, .trailing])
        .padding(.top, 8)
    }
    
    private var actionButtons: some View {
        VStack {
            HStack {
                Button(action: { coordinator.push(.reportForm(station)) }) {
                    Image("warning")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: 120, height: 60)
                }
                Button(action: { addRemoveStationToFavorites(station: station) }) {
                    Image(isFavorite ? "icn_fav" : "icn_fav_unselected")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: 120, height: 60)
                }
            }
            .padding()
            .frame(width: 360, height: 80)
            .overlay(
                RoundedRectangle(cornerRadius: 10)
                    .stroke(Color.gray.opacity(0.4), lineWidth: 1)
            )
        }
        .padding([.leading, .trailing])
        .padding(.top, 8)
    }
    
    private var useStationButton: some View {
        Button(action: { coordinator.push(.useStationView(station)) }) {
            Capsule()
                .frame(height: 45, alignment: .center)
                .foregroundColor(.blue)
                .overlay(
                    Text("Use this station")
                        .foregroundColor(.white)
                )
        }
        .padding()
    }
    
    private func openMapsApp() {
        let destinationCoordinate = CLLocationCoordinate2D(latitude: station.latitude, longitude: station.longitude)
        let destinationPlacemark = MKPlacemark(coordinate: destinationCoordinate)
        let destinationMapItem = MKMapItem(placemark: destinationPlacemark)
        destinationMapItem.name = station.address
        
        let options = [MKLaunchOptionsDirectionsModeKey: MKLaunchOptionsDirectionsModeDriving]
        destinationMapItem.openInMaps(launchOptions: options)
    }
    
    private func showAlert(message: String) {
        alertMessage = message
        isShowingAlert = true
    }
    
    private func addRemoveStationToFavorites(station: CustomStation) {
        let auth = Auth.auth()
        guard let currentUser = auth.currentUser else {
            showAlert(message: "No user found")
            return
        }
        
        let db = Firestore.firestore()
        let userFavoritesRef = db.collection("UserInfo").document(currentUser.uid).collection("FavoriteInfo")
        
        userFavoritesRef.document(String(station.id)).getDocument { (documentSnapshot, error) in
            if let error = error {
                print("Error checking favorite status: \(error)")
                return
            }
            
            db.runTransaction({ (transaction, errorPointer) -> Any? in
                let stationRef = userFavoritesRef.document(String(station.id))
                if documentSnapshot?.exists ?? false {
                    // If the station is already a favorite, remove it
                    transaction.deleteDocument(stationRef)
                } else {
                    // If the station is not a favorite, add it
                    let favoriteInfo: [String: Any] = [
                        "stationId": station.id,
                        "stationData": station.dataRepresentation(),
                        "addedAt": Timestamp(date: Date()) // You can add more fields if needed
                    ]
                    transaction.setData(favoriteInfo, forDocument: stationRef)
                }
                return nil
            }) { (object, error) in
                if let error = error {
                    print("Transaction failed: \(error)")
                } else {
                    getMyStations()
                }
            }
        }
    }

    
    private func getMyStations() {
        var customStations = [CustomStation]()
        let db = Firestore.firestore()
        let auth = Auth.auth()
        guard let currentUser = auth.currentUser else {
            print("No current user")
            return
        }
        
        // Fetch favorite station IDs from UserInfo/FavoriteInfo collection
        let favoriteInfoCollectionRef = db.collection("UserInfo").document(currentUser.uid).collection("FavoriteInfo")
        favoriteInfoCollectionRef.getDocuments { (querySnapshot, error) in
            if let error = error {
                print("Error getting favorite documents: \(error)")
                return
            }
            
            guard let documents = querySnapshot?.documents else {
                print("No favorite documents")
                return
            }
            
            // Extract station IDs of favorite stations
            let favoriteStationIDs = documents.compactMap { document in
                document.data()["stationId"] as? String
            }
            
            // Query StationInfo collection with favorite station IDs
            let stationInfoCollectionRef = db.collection("StationInfo")
            let fetchOperations = DispatchGroup()
            
            for stationID in favoriteStationIDs {
                fetchOperations.enter()
                let query = stationInfoCollectionRef.whereField("id", isEqualTo: stationID)
                query.getDocuments { (document, error) in
                    defer { fetchOperations.leave() }
                    if let error = error {
                        print("Error getting station document for \(stationID): \(error)")
                        return
                    }
                    guard let document = document?.documents.first else {
                        print("Station document for \(stationID) does not exist")
                        return
                    }
                    
                    let data = document.data()
                    guard let id = data["id"] as? String,
                          let address = data["Address"] as? String,
                          let charger = data["Charger"] as? String,
                          let level = data["Level"] as? String,
                          let rate = data["Rate"] as? String,
                          let phone = data["Phone"] as? String,
                          let latitude = data["Latitude"] as? Double,
                          let longitude = data["Longitude"] as? Double else {
                        return
                    }
                    
                    let customStation = CustomStation(id: id, address: address, charger: charger, phone: phone, level: level, rate: rate, latitude: latitude, longitude: longitude)
                    customStations.append(customStation)
                }
            }
            
            fetchOperations.notify(queue: .main) {
                // Update UI with fetched custom stations
                self.myStation = customStations
                self.isFavorite = customStations.contains(where: { $0.id == self.station.id })
            }
        }
    }
}

struct SectionTitle: View {
    var title: String
    
    var body: some View {
        Text(title)
            .font(.title2)
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding([.leading])
            .foregroundStyle(.gray.opacity(0.8))
    }
}

struct SectionDetail: View {
    var detail: String
    
    var body: some View {
        Text(detail)
            .fontWeight(.light)
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(.leading)
    }
}

// Assuming CustomStation has a method to get data representation
extension CustomStation {
    func dataRepresentation() -> [String: Any] {
        return [
            "id": self.id,
            "name": self.address,
            // Add other station fields as necessary
        ]
    }
}
