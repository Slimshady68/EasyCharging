
import SwiftUI

struct StationCell: View {
    var titleHeader: String
    var charger: String
    var access: String
    var level: String
    var price: String
    var onDelete: () -> Void

    var body: some View {
        HStack {
            VStack(alignment: .leading, spacing: 4) {
                HStack {
                    Text(titleHeader)
                        .font(.title2)
                        .fontWeight(.medium)
                    Spacer()
                    Button(action: onDelete) {
                        Image(systemName: "trash")
                            .foregroundColor(.red)
                    }
                    .buttonStyle(PlainButtonStyle()) // Ensures the button does not affect the layout
                    .padding(.trailing, 8)
                }
                Text("Charger: \(charger)")
                    .foregroundStyle(.secondary)
                    .fontWeight(.semibold)
                Text("Access: \(access)")
                    .foregroundStyle(.secondary)
                    .fontWeight(.semibold)
                Text("Level: \(level)")
                    .foregroundStyle(.secondary)
                    .fontWeight(.semibold)
                Text("Price \(price)/Hour")
                    .foregroundStyle(.secondary)
                    .fontWeight(.semibold)
            }
            .padding()
            .shadow(color: Color.gray.opacity(0.4), radius: 5, x: 0, y: 2)
            .overlay(
                RoundedRectangle(cornerRadius: 10)
                    .stroke(Color.gray.opacity(0.4), lineWidth: 1)
            )
            .contentShape(Rectangle()) // Define the tappable area
        }
    }
}
