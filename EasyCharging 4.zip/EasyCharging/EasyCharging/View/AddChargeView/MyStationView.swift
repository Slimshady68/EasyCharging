import SwiftUI
import FirebaseFirestore
import FirebaseAuth

struct MyStationView: View {
    
    @State private var isLoading = false
    @State private var showAlert = false
    @State private var stationToDelete: CustomStation?
    @State private var stations = [CustomStation]()
    @Environment(NavigationCoordinator.self) var coordinator: NavigationCoordinator
    
    var body: some View {
        VStack {
            if isLoading {
                ProgressView("Loading...") // Show progress indicator
                    .progressViewStyle(CircularProgressViewStyle())
                    .padding()
            } else {
                if stations.count > 0 {
                    List(stations) { chargeData in
                        StationCell(
                            titleHeader: chargeData.address,
                            charger: chargeData.charger,
                            access: "Public",
                            level: chargeData.level,
                            price: chargeData.rate
                        ) {
                            stationToDelete = chargeData
                            showAlert = true
                        }
                        .onTapGesture {
                            coordinator.push(.stationDetail(chargeData))
                        }
                        .listRowSeparator(.hidden)
                    }
                    .listStyle(.plain)
                    .alert(isPresented: $showAlert) {
                                        Alert(
                                            title: Text("Confirm Delete"),
                                            message: Text("Are you sure you want to delete this station?"),
                                            primaryButton: .destructive(Text("Delete")) {
                                                if let station = stationToDelete {
                                                    deleteStationFromFirestore(station: station)
                                                }
                                            },
                                            secondaryButton: .cancel()
                                        )
                                    }
                } else {
                    Spacer()
                    Text("No Data Found")
                        .font(.system(size: 18, weight: .semibold))
                }
                Spacer()
                
                Button(action: {
                    coordinator.push(.rentYourCharger)
                }) {
                    Capsule()
                        .frame(height: 45, alignment: .center)
                        .foregroundColor(.blue)
                        .overlay(
                            Text("Add Charge Station")
                                .foregroundColor(.white)
                        )
                }
                .padding()
            }
        }
        .navigationBarBackButtonHidden(false)
        .navigationTitle("Station List")
        .onAppear {
            getMyStations()
        }
    }
    
    func deleteStationFromFirestore(station: CustomStation) {
        let db = Firestore.firestore()
        let collectionRef = db.collection("StationInfo")
        let query = collectionRef.whereField("id", isEqualTo: station.id)
        
        query.getDocuments { (querySnapshot, error) in
            if let error = error {
                print("Error finding station: \(error.localizedDescription)")
                return
            }
            
            guard let documents = querySnapshot?.documents, let document = documents.first else {
                print("No matching station found.")
                return
            }
            
            document.reference.delete { error in
                if let error = error {
                    print("Error deleting station: \(error.localizedDescription)")
                } else {
                    print("Station successfully deleted.")
                    if let index = stations.firstIndex(where: { $0.id == station.id }) {
                        stations.remove(at: index)
                    }
                }
            }
        }
    }
    
    // Function to fetch station data
    func getMyStations() {
        isLoading = true
        var customStations = [CustomStation]()
        let db = Firestore.firestore()
        let auth = Auth.auth()
        guard let currentUser = auth.currentUser else {
            print("No current user")
            isLoading = false
            return
        }
        
        let collectionRef = db.collection("StationInfo")
        let query = collectionRef.whereField("UID", isEqualTo: currentUser.uid)
        
        query.getDocuments { (querySnapshot, error) in
            if let error = error {
                print("Error getting documents: \(error)")
                isLoading = false
                return
            }
            
            guard let documents = querySnapshot?.documents else {
                print("No documents")
                isLoading = false
                return
            }
            
            for document in documents {
                let data = document.data()
                guard let address = data["Address"] as? String,
                      let charger = data["Charger"] as? String,
                      let level = data["Level"] as? String,
                      let rate = data["Rate"] as? String,
                      let phone = data["Phone"] as? String,
                      let latitude = data["Latitude"] as? Double,
                      let longitude = data["Longitude"] as? Double,
                      let id = data["id"] as? String else {
                    continue
                }
                let customStation = CustomStation(id: id, address: address, charger: charger, phone: phone, level: level, rate: rate, latitude: latitude, longitude: longitude)
                customStations.append(customStation)
            }
            
            // Update the state object with fetched data
            DispatchQueue.main.async {
                isLoading = false
                self.stations = customStations
            }
        }
    }
}

#Preview {
    MyStationView()
}
