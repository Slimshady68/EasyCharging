
import SwiftUI
import FirebaseAuth
import FirebaseFirestore
import CoreLocation
import CommonCrypto
import Foundation

struct RentYourCharger: View {
    
    @State private var isLoading = false
    
    @State private var isShowingAlert = false
    @State private var alertMessage = ""
    
    @State var connector = ""
    @State var level = ""
    @State var price = ""
    @State var address = ""
    @State var phone = ""
    @Environment(NavigationCoordinator.self) var coordinator: NavigationCoordinator
    
    var body: some View {
        VStack(alignment: .center, spacing: 16){
            CustomTextField(placeholder:"Connectors", text: $connector)
            CustomTextField(placeholder:"Level", text: $level)
            CustomTextField(placeholder:"Price/Hour", text: $price)
            CustomTextField(placeholder:"Phone", text: $phone)
            CustomTextField(placeholder:"Full Address", text: $address)
            
            VStack (spacing: 8){
                Button(action: {
                    getAddressLatLngAndStoreStation(address: address, charger: connector, level: level, rate: price, phone: phone)
                    self.isLoading.toggle()
                }) {
                    if isLoading {
                        ProgressView()
                            .progressViewStyle(CircularProgressViewStyle())
                            .foregroundColor(.white)
                    } else {
                        Capsule()
                            .frame(height: 45, alignment: .center)
                            .foregroundColor(.blue)
                            .overlay(
                                Text("Submit")
                                    .foregroundColor(.white)
                            )
                    }
                }
                .disabled(isLoading)
                .padding([.leading,.trailing, .top], 16)
            }
            .navigationBarBackButtonHidden(false)
            .navigationTitle("Rent your charger")
            Spacer()
        }
        .alert(isPresented: $isShowingAlert) {
            Alert(title: Text("Error"), message: Text(alertMessage), dismissButton: .default(Text("OK")))
        }
    }
}

extension RentYourCharger {
    func showAlert(message: String) {
        alertMessage = message
        isShowingAlert = true
    }
    //    getAddressLatLngAndStoreStation(address: "47 W 13th St, New York, NY 10011, US", charger: "Charger", level: "Level1", rate: "10")
        
        //Store custom station
    func getAddressLatLngAndStoreStation(address: String, charger: String, level: String, rate: String, phone: String) {
            let geocoder = CLGeocoder()
            geocoder.geocodeAddressString(address) { (placemarks, error) in
                guard let placemark = placemarks?.first else {
                    if let error = error {
                        showAlert(message: "Geocoding failed with error: \(error.localizedDescription)")
                        self.isLoading.toggle()
                    } else {
                        showAlert(message: "No placemarks found")
                        self.isLoading.toggle()
                        print("No placemarks found")
                    }
                    return
                }
                
                let lat = placemark.location?.coordinate.latitude ?? 0.0
                let lng = placemark.location?.coordinate.longitude ?? 0.0
                
                let auth = Auth.auth()
                if let currentUser = auth.currentUser {
                    let db = Firestore.firestore()
                    let collectionRef = db.collection("StationInfo")
                    
                    var newCustomStation: [String: Any] = [
                        "UID": currentUser.uid,
                        "Address": address,
                        "Charger": charger,
                        "Level": level,
                        "Rate": rate,
                        "Phone": phone,
                        "Latitude": lat,
                        "Longitude": lng,
                        "Favourite": false
                    ]
                    
                    let documentReference = collectionRef.addDocument(data: newCustomStation) { (error) in
                        if let error = error {
                            showAlert(message: "Error adding document: \(error)")
                            self.isLoading.toggle()
                        }
                    }
                    let docId = documentReference.documentID
                    
                    // Update the document with the intId field
                    let updateData: [String: Any] = [
                        "id": String(Int.random(in: 1...1000000))
                    ]
                    
                    collectionRef.document(documentReference.documentID).updateData(updateData) { error in
                        if let error = error {
                            showAlert(message: "Error updating document: \(error)")
                            self.isLoading.toggle()
                        } else {
                            self.coordinator.pop()
                        }
                    }
                } else {
                    print("No current user")
                }
            }
        }
        
        func didToUniqueInt(did: String) -> Int {
            // Convert the UID string to bytes
            guard let uidData = did.data(using: .utf8) else {
                return 0 // Return a default value or handle the error appropriately
            }
            
            // Compute the SHA256 hash of the UID bytes
            var digest = [UInt8](repeating: 0, count: Int(CC_SHA256_DIGEST_LENGTH))
            uidData.withUnsafeBytes { bytes in
                _ = CC_SHA256(bytes.baseAddress, CC_LONG(uidData.count), &digest)
            }
            
            // Convert the digest bytes to a BigInteger
            let bigInt = Data(digest).reduce(0) { result, byte in
                (result << 8) | Int(byte)
            }
            
            // Get the absolute value of the BigInteger as an Int
            let uniqueInt = abs(Int(bigInt))
            
            // Return the unique integer
            return uniqueInt
        }
}

#Preview {
    RentYourCharger()
}
