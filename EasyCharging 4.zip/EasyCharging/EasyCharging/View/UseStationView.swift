import SwiftUI

struct UseStationView: View {
    @Environment(NavigationCoordinator.self) var coordinator: NavigationCoordinator
    @State private var selectedTime = "1:00"
        let timeOptions = ["1:00", "2:00", "3:00", "4:00", "5:00"]
    
    var station: CustomStation
    
    var body: some View {
        VStack(alignment: .leading, spacing: 20) {
            HStack {
                Text("Charger Type:")
                    .font(.headline)
                Spacer()
                Text(station.charger)
                    .font(.subheadline)
                    .foregroundColor(.gray)
            }
            HStack {
                Text("Address:")
                    .font(.headline)
                Spacer()
                Text(station.address)
                    .font(.subheadline)
                    .foregroundColor(.gray)
            }
            HStack {
                Text("Open Time:")
                    .font(.headline)
                Spacer()
                Text("11:00 AM to 5:00 PM")
                    .font(.subheadline)
                    .foregroundColor(.gray)
            }
            HStack {
                Text("Price:")
                    .font(.headline)
                Spacer()
                Text("$\(station.rate) per hour")
                    .font(.subheadline)
                    .foregroundColor(.gray)
            }
            Button(action: {
                coordinator.push(.waitingStationView(station))
            }, label: {
                Capsule()
                    .frame(height: 45, alignment: .center)
                    .foregroundColor(.blue)
                    .overlay(
                    Text("Use Now")
                        .foregroundColor(.white)
                    )
            })
            .padding(.bottom, 4)
            HStack {
                            Text("Select Time:")
                                .font(.headline)
                            Spacer()
                            Picker("Select Time", selection: $selectedTime) {
                                ForEach(timeOptions, id: \.self) { time in
                                    Text(time)
                                }
                            }
                            .pickerStyle(MenuPickerStyle()) // Optional: Use menu style for better look
                        }
            Button(action: {
                coordinator.push(.waitingStationView(station))
            }, label: {
                Capsule()
                    .frame(height: 45, alignment: .center)
                    .foregroundColor(.blue)
                    .overlay(
                    Text("Use later at \(selectedTime)")
                        .foregroundColor(.white)
                    )
            })
            .padding(.bottom, 4)
            Spacer()
        }
        .padding()
        .navigationTitle(station.address)
    }
}
