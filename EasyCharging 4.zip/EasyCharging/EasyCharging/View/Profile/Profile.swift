
import SwiftUI

struct Profile: View {
    var body: some View {
        VStack {
            HStack {
                Text("Welcome!")
                    .font(.title)
                Spacer()
                Button(action: {
                    
                }) {
                    Text("Log out")
                        .aspectRatio(contentMode: .fit)
                        .frame(width: 80, height: 40)
                }
                .border(Color.blue)
            }
            .padding()
            Spacer()
            Text("Anmol Neupane\("")")
            Spacer()
            NavigationLink(destination: RentYourCharger()) {
   
            }
            
            
        }
    }
}

#Preview {
    Profile()
}
