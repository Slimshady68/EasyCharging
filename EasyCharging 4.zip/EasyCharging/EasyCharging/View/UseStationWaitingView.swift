import SwiftUI

struct UseStationWaitingView: View {
    
    @Environment(NavigationCoordinator.self) var coordinator: NavigationCoordinator
    
    var station: CustomStation
    
    var body: some View {
        VStack(alignment: .leading, spacing: 20) {
            Text("Thank you for choosing station at \(station.address)")
                    .font(.headline)
                    .frame(maxWidth: .infinity, alignment: .center)
                    .multilineTextAlignment(.center)
            Text("The address of the station is: \(station.address)")
                .font(.headline)
                .frame(maxWidth: .infinity, alignment: .center)
                .multilineTextAlignment(.center)
            
            Text("Please arrive at the station within 5 minutes.")
                .font(.headline)
                .frame(maxWidth: .infinity, alignment: .center)
                .multilineTextAlignment(.center)
            Button(action: {
                coordinator.push(.verifyStationView(station))
            }, label: {
                Capsule()
                    .frame(height: 45, alignment: .center)
                    .foregroundColor(.blue)
                    .overlay(
                    Text("I have arrived")
                        .foregroundColor(.white)
                    )
            })
            .padding(.bottom, 4)
            .padding(.top, 24)
            Spacer()
        }
        .padding()
        .navigationTitle(station.address)
    }
}
