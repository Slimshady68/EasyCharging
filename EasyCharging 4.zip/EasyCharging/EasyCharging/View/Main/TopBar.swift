import SwiftUI

struct TopBar: View {
    
    @Binding var x: CGFloat
    
    var body: some View {
        VStack {
            HStack {
//                Button(action: {
//                    withAnimation {
//                        x = 0
//                    }
//                }, label: {
//                    Image(systemName: "line.horizontal.3")
//                        .font(.system(size: 24))
//                        .foregroundColor(.blue)
//                })
//                
                Spacer(minLength: 0)
                
                Image("icn_logo")
                    .resizable()
                    .scaledToFill()
                    .padding(.trailing)
                    .frame(width: 200, height: 20)
                    .foregroundColor(.blue)
                
                Spacer(minLength: 0)
            }
            .padding()
            
            Rectangle()
                .frame(width: UIScreen.main.bounds.width, height: 1)
                .foregroundColor(.gray)
                .opacity(0.3)
        }
        .background(.white)
    }
}
