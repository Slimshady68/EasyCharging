import SwiftUI
import FirebaseFirestore
import FirebaseAuth

struct FavoriteView: View {

    @State private var isLoading = false
    @State private var stations = [CustomStation]()
    
    let data = MockData.chargerdata
    @Environment(NavigationCoordinator.self) var coordinator: NavigationCoordinator
    var body: some View {
        VStack {
            Text("Favorite")
                .font(.system(size: 18, weight: .semibold))
            if isLoading {
                ProgressView("Loading...") // Show progress indicator
                    .progressViewStyle(CircularProgressViewStyle())
                    .padding()
            } else {
                if stations.count > 0 {
                    List(stations) { chargeData in
                        FavoriteCell(
                            titleHeader: chargeData.address,
                            charger: chargeData.charger,
                            access: "Public",
                            level: chargeData.level
                        )
                        .onTapGesture {
                            coordinator.push(.stationDetail(chargeData))
                        }
                        .listRowSeparator(.hidden)
                    }
                    .navigationBarBackButtonHidden(false)
                    .listStyle(.plain)
                } else {
                    Spacer()
                    Text("No Data Found")
                        .font(.system(size: 18, weight: .semibold))
                    Spacer()
                }
            }
        }
        .onAppear {
            getFavouriteStations()
        }
    }
}

extension FavoriteView {
    // Function to fetch station data
    func getFavouriteStations() {
        isLoading = true
        var customStations = [CustomStation]()
        let db = Firestore.firestore()
        let auth = Auth.auth()
        guard let currentUser = auth.currentUser else {
            print("No current user")
            isLoading = false
            return
        }
        
        let favoriteInfoCollectionRef = db.collection("UserInfo").document(currentUser.uid).collection("FavoriteInfo")
        
        favoriteInfoCollectionRef.getDocuments { (querySnapshot, error) in
            if let error = error {
                print("Error getting documents: \(error)")
                isLoading = false
                return
            }
            
            guard let documents = querySnapshot?.documents else {
                print("No documents")
                isLoading = false
                return
            }
            
            // Extract IDs of favorite stations
            let favoriteStationIDs = documents.compactMap { document in
                    document.data()["stationId"] as? String
                }
            
            // Fetch full station information for each favorite station
            let stationInfoCollectionRef = db.collection("StationInfo")
            let fetchOperations = DispatchGroup()
            
            for stationID in favoriteStationIDs {
                fetchOperations.enter()
                let query = stationInfoCollectionRef.whereField("id", isEqualTo: stationID)
                query.getDocuments { (document, error) in
                    defer { fetchOperations.leave() }
                    if let error = error {
                        isLoading = false
                        print("Error getting station document for \(stationID): \(error)")
                        return
                    }
                    guard let document = document?.documents.first else {
                        isLoading = false
                        print("Station document for \(stationID) does not exist")
                        return
                    }
                    
                    let data = document.data()
                    guard let id = data["id"] as? String,
                          let address = data["Address"] as? String,
                          let charger = data["Charger"] as? String,
                          let level = data["Level"] as? String,
                          let rate = data["Rate"] as? String,
                          let phone = data["Phone"] as? String,
                          let latitude = data["Latitude"] as? Double,
                          let longitude = data["Longitude"] as? Double else {
                        return
                    }
                    
                    let customStation = CustomStation(id: id, address: address, charger: charger, phone: phone, level: level, rate: rate, latitude: latitude, longitude: longitude)
                    customStations.append(customStation)
                }
            }
            
            fetchOperations.notify(queue: .main) {
                isLoading = false
                self.stations = customStations
            }
        }
    }
}

#Preview {
    FavoriteView()
}
