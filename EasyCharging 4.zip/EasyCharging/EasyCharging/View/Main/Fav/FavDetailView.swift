
import SwiftUI

struct FavDetailView: View {
    
    @Environment(NavigationCoordinator.self) var coordinator: NavigationCoordinator
    
    var body: some View {
        VStack{
            ScrollView {
                VStack {
                    VStack {
                        HStack{
                            Text("8201 Tapa Avenue, Reseda")
                            Spacer()
                            Image(systemName: "location")
                        }
                    }
                    .padding()
                    .frame(maxWidth: .infinity, minHeight: 10)
                    .overlay(
                        RoundedRectangle(cornerRadius: 10)
                            .stroke(Color.gray.opacity(0.4), lineWidth: 1)
                    )
                    
                    VStack(spacing: 8) {
                        
                        Text("Access")
                            .font(.title2)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding([.leading,.top])
                            .foregroundStyle(.gray.opacity(0.8))
                        
                        Text("Public\("")")
                            .fontWeight(.light)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding(.leading)
                        
                        Text("Station Status")
                            .font(.title2)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding([.leading,.top])
                            .foregroundStyle(.gray.opacity(0.8))
                        
                        Text("Functional\("")")
                            .fontWeight(.light)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding(.leading)
                        Text("Phone")
                            .font(.title2)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding([.leading,.top])
                            .foregroundStyle(.gray.opacity(0.8))
                        
                        Text("Phone\("")")
                            .fontWeight(.light)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding(.leading)
                        
                        Text("Access Time")
                            .font(.title2)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding([.leading,.top])
                            .foregroundStyle(.gray.opacity(0.8))
                        
                        Text("24 Hours daily\("")")
                            .fontWeight(.light)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding(.leading)
                        
                        Text("Pricing")
                            .font(.title2)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding([.leading,.top])
                            .foregroundStyle(.gray.opacity(0.8))
                        
                        Text("120.9\("")")
                            .fontWeight(.light)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding(.leading)
                        
                        Text("Direction Details")
                            .font(.title2)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding([.leading,.top])
                            .foregroundStyle(.gray.opacity(0.8))
                        
                        Text("None\("")")
                            .fontWeight(.light)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding(.leading)
                        
                        Text("Charge Network")
                            .font(.title2)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding([.leading,.top])
                            .foregroundStyle(.gray.opacity(0.8))
                        
                        Text("FLO\("")")
                            .fontWeight(.light)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding(.leading)
                        
                        Text("Network Site")
                            .font(.title2)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding([.leading,.top])
                            .foregroundStyle(.gray.opacity(0.8))
                        
                        Text("Link.com\("")")
                            .fontWeight(.light)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding(.leading)
                        
                        Spacer()
                    }
                    .frame(width: 360, height: 650)
                    .overlay(
                        RoundedRectangle(cornerRadius: 10)
                            .stroke(Color.gray.opacity(0.4), lineWidth: 1)
                    )
                    VStack {
                        Text("Connectors")
                            .font(.title2)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .foregroundStyle(.gray.opacity(0.8))
                        
                        Text("J1772 LEVEL 2X 1")
                            .fontWeight(.light)
                            .frame(maxWidth: .infinity, alignment: .leading)
                        
                    }
                    .padding()
                    .frame(width: 360, height: 80)
                    .overlay(
                        RoundedRectangle(cornerRadius: 10)
                            .stroke(Color.gray.opacity(0.4), lineWidth: 1)
                    )
                    
                    VStack {
                        HStack {
                            Button(action: {
//                                coordinator.push(.reportForm)
                            }) {
                                Image("warning")
                                    .resizable()
                                    .aspectRatio(contentMode: .fit)
                                    .frame(width: 120, height: 60)
                            }
                            Button(action: {
                                
                            }) {
                                Image("icn_fav")
                                    .resizable()
                                    .aspectRatio(contentMode: .fit)
                                    .frame(width: 120, height: 60)
                            }
                        }
                        .padding()
                        .frame(width: 360, height: 80)
                        .overlay(
                            RoundedRectangle(cornerRadius: 10)
                                .stroke(Color.gray.opacity(0.4), lineWidth: 1)
                        )
                    }
                    
                }
            }
            .padding()
            .navigationTitle("Favourite Detail")
        }
        
    }
}
    #Preview {
        FavDetailView()
    }
