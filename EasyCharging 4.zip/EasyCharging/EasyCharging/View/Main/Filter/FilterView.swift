
import SwiftUI

struct FilterView: View {
    
    @State var isOnPrivateMakersVisible: Bool = false
    @State var isOnInactiveMarkersVisible: Bool = false
    @State var isOnLevel1: Bool = false
    @State var isOnLevel2: Bool = false
    @State var isOnLevel3: Bool = false
    @State var isOnEVPlugJ1772: Bool = false
    @State var isOnCSSJ1772COMBO: Bool = false
    @State var isOnTesla: Bool = false
    @State var isOnCHAdeMO: Bool = false
    @State var isOnNEMA1450: Bool = false
    @State var isOnNEMA515: Bool = false
    @State var isOnNEMA520: Bool = false
    
    
    var body: some View {
        VStack {
            ScrollView{
                VStack(spacing: 12) {
                    
                    Text("General Preferences")
                        .fontWeight(.regular)
                        .font(.title2)
                        .padding(.leading)
                 
                    Divider()
                        .frame(height: 2)
                        .background(Color.gray.opacity(0.4))
                       
                    Spacer(minLength: 4)
                    
                    Toggle("Private Makers Visible", isOn: $isOnPrivateMakersVisible)
                        .font(.title3)
                        .toggleStyle(SwitchToggleStyle(tint: .green))
                        .tint(.green)
                    
                    Toggle("Inactive Markers Visible", isOn: $isOnInactiveMarkersVisible)
                        .font(.title3)
                        .toggleStyle(SwitchToggleStyle(tint: .green))
                        .tint(.green)
                    
                    Spacer(minLength: 12)
                    
                    Text("Charger Levels")
                        .fontWeight(.regular)
                        .font(.title2)
                        .padding(.leading)
                 
                    Divider()
                        .frame(height: 2)
                        .background(Color.gray.opacity(0.4))
                       
                    Spacer(minLength: 4)
                    
                    Toggle("Level 1", isOn: $isOnLevel1)
                        .font(.title3)
                        .toggleStyle(SwitchToggleStyle(tint: .green))
                        .tint(.green)
                    
                    Toggle("Level 2", isOn: $isOnLevel2)
                        .font(.title3)
                        .toggleStyle(SwitchToggleStyle(tint: .green))
                        .tint(.green)
                    
                    Toggle("Level 3", isOn: $isOnLevel3)
                        .font(.title3)
                        .toggleStyle(SwitchToggleStyle(tint: .green))
                        .tint(.green)
                    
                    
                    Spacer(minLength: 12)
                    
                    Text("Connector Types")
                        .fontWeight(.regular)
                        .font(.title2)
                        .padding(.leading)
                 
                    Divider()
                        .frame(height: 2)
                        .background(Color.gray.opacity(0.4))
                       
                    Spacer(minLength: 4)
                    
                    Toggle("EV Plug(J1772)", isOn: $isOnEVPlugJ1772)
                        .font(.title3)
                        .toggleStyle(SwitchToggleStyle(tint: .green))
                        .tint(.green)
                    
                    Toggle("CSS(J1772COMBO)", isOn: $isOnCSSJ1772COMBO)
                        .font(.title3)
                        .toggleStyle(SwitchToggleStyle(tint: .green))
                        .tint(.green)
                    
                    Toggle("Tesla", isOn: $isOnTesla)
                        .font(.title3)
                        .toggleStyle(SwitchToggleStyle(tint: .green))
                        .tint(.green)
                    
                    Toggle("CHAdeMO", isOn: $isOnCHAdeMO)
                        .font(.title3)
                        .toggleStyle(SwitchToggleStyle(tint: .green))
                        .tint(.green)
                    
                    Toggle("NEMA 14-50", isOn: $isOnNEMA1450)
                        .font(.title3)
                        .toggleStyle(SwitchToggleStyle(tint: .green))
                        .tint(.green)
                    
                    Toggle("NEMA 5-15", isOn: $isOnNEMA515)
                        .font(.title3)
                        .toggleStyle(SwitchToggleStyle(tint: .green))
                        .tint(.green)
                    
                    Toggle("NEMA 5-20", isOn: $isOnNEMA520)
                        .font(.title3)
                        .toggleStyle(SwitchToggleStyle(tint: .green))
                        .tint(.green)
                    
                }
                .scrollIndicators(.hidden)
                .padding()
                
                
            }
            .padding()
            
        }
    }
}

#Preview {
    FilterView(isOnPrivateMakersVisible: true,
               isOnInactiveMarkersVisible: true,
               isOnLevel1: true, isOnLevel2: true,
               isOnLevel3: true,
               isOnEVPlugJ1772: true,
               isOnCSSJ1772COMBO: true,
               isOnTesla: true,
               isOnCHAdeMO: true,
               isOnNEMA1450: true,
               isOnNEMA515: true,
               isOnNEMA520: true)
}
