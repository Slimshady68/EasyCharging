//
//  SwiftUIView.swift
//  EasyCharging
//
//  Created by Outcode-1 on 16/05/2024.
//

import SwiftUI

struct SwiftUIView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    SwiftUIView()
}
