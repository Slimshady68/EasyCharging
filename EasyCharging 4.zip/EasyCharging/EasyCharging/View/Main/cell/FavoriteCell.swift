

import SwiftUI


struct FavoriteCell: View {
    
    var titleHeader: String
    var charger: String
    var access: String
    var level: String
    
   
    var body: some View {
        HStack {
            VStack (alignment: .leading , spacing: 4){
                HStack{
                    Text("\(String(describing: titleHeader))")
                        .font(.title2)
                        .fontWeight(.medium)
                        
                    Spacer()
                    Image(systemName: "info.circle")
                }
                Text("Status: \(String(describing: "Functional"))")
                    .foregroundStyle(.secondary)
                    .fontWeight(.semibold)
                Text("Access: \(String(describing: access))")
                    .foregroundStyle(.secondary)
                    .fontWeight(.semibold)
                Text("Charger: \(String(describing: charger))")
                    .foregroundStyle(.secondary)
                    .fontWeight(.semibold)
                Text("Level: \(String(describing: level))")
                    .foregroundStyle(.secondary)
                    .fontWeight(.semibold)
                
            }
            .padding()
            .shadow(color: Color.gray.opacity(0.4), radius: 5, x: 0, y: 2)
            .overlay(
                RoundedRectangle(cornerRadius: 10)
                    .stroke(Color.gray.opacity(0.4), lineWidth: 1)
            )
            
           
        }
    }
}
