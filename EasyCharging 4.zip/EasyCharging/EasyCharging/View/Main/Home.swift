
import SwiftUI

struct Home: View {
    
    @EnvironmentObject var viewModel: AuthViewModel
    @Environment(NavigationCoordinator.self) var coordinator: NavigationCoordinator
    @State var selectedIndex = 0
    @State var showCreateTweet = false
    @State var text = ""
    
    var body: some View {
        VStack{
            ZStack{
                TabView(selection: $selectedIndex) {
                   MapView()
                        .tabItem {
                            tabItemView(imageName: "icn_home", title: "Home", index: 0, screen: .mapView)
                        }
                    
                    FavoriteView()
                        .tabItem {
                            tabItemView(imageName: "icn_fav_tab", title: "Favorite", index: 1, screen: .favoriteView)
                        }
                   UserProfileView()
                        .tabItem {
                            tabItemView(imageName: "icn_user_placeholder", title: "Profile", index: 2,screen: .profileView)
                        }
                }
                .background(Color.white)
                
//                VStack {
//                    Spacer()
//                    HStack {
//                        Spacer()
//                        Button(action: {
//                            showCreateTweet.toggle()
//                        }, label: {
//                            Image("icn_create_tweet")
//                                .renderingMode(.template)
//                                .resizable()
//                                .frame(width: 20, height: 20)
//                                .padding()
//                                .foregroundColor(.white)
//                                .background(.blue)
//                                .clipShape(Circle())
//                                .padding()
//                        })
//                        .sheet(isPresented: $showCreateTweet, content: {
//                            Text("Test")
//                        })
//                    }
//                    .padding(.bottom, 65)
//                }
            }
        }
    }
    
    // Helper function to create tab item view
    private func tabItemView(imageName: String, title: String, index: Int ,screen: Screens) -> some View {
        VStack {
            if selectedIndex == index {
                Image(imageName)
                    .renderingMode(.template)
                    .foregroundColor(.blue)
                Text(title)
                    .foregroundColor(.blue)
                    .font(.caption)
            } else {
                Image(imageName)
                    .renderingMode(.template)
                    .foregroundColor(.gray)
                Text(title)
                    .font(.caption)
            }
        }
        .onTapGesture {
          
            coordinator.push(screen)
            selectedIndex = index
        }
    }
}

struct Home_Previews: PreviewProvider {
    static var previews: some View {
        Home()
    }
}

//import SwiftUI
//
//struct Home: View {
//    
//    @EnvironmentObject var viewModel: AuthViewModel
//    @Environment(NavigationCoordinator.self) var coordinator: NavigationCoordinator
//    @State var selectedIndex = 0
//    @State var showCreateTweet = false
//    @State var text = ""
//    var body: some View {
//        VStack{
//            ZStack{
//                TabView {
//                    MapView()
//                        .onTapGesture {
//                            selectedIndex = 0
//                        }
//                        .tabItem {
//                            VStack {
//                                if selectedIndex == 0 {
//                                    Image("icn_home")
//                                        .renderingMode(.template)
//                                        .foregroundColor(Color.blue)
//                                    Text("Home")
//                                        .foregroundColor(.blue)
//                                        .font(.caption)
//                                } else {
//                                    Image("icn_home")
//                                    Text("Home")
//                                        .font(.caption)
//                                }
//                            }
//                        }
//                    
//                    FavoriteView()
//                        .onTapGesture {
//                            selectedIndex = 1
//                        }
//                        .tabItem {
//                            VStack {
//                                if selectedIndex == 1 {
//                                    Image(systemName: "heart.fill")
//                                        .renderingMode(.template)
//                                        .foregroundColor(Color.blue)
//                                    Text("Favorite")
//                                        .foregroundColor(.blue)
//                                        .font(.caption)
//                                } else {
//                                    Image(systemName: "heart.fill")
//                                    Text("Favorite")
//                                        .font(.caption)
//                                }
//                            }
//                        }
//                    
//                    Text("Profile")
//                        .onTapGesture {
//                            selectedIndex = 2
//                        }
//                        .tabItem {
//                            VStack {
//                                if selectedIndex ==  2 {
//                                    Image("icn_user_placeholder")
//                                        .renderingMode(.template)
//                                        .foregroundColor(Color.blue)
//                                    Text("Profile")
//                                        .foregroundColor(.blue)
//                                        .font(.caption)
//                                } else {
//                                    Image("icn_user_placeholder")
//                                    Text("Profile")
//                                        .font(.caption)
//                                }
//                            }
//                        }
//                    
//                }
//                .background(Color.white) 
//                VStack {
//                    Spacer()
//                    HStack {
//                        Spacer()
//                        Button(action: {
//                            showCreateTweet.toggle()
//                        }, label: {
//                            Image("icn_create_tweet")
//                                .renderingMode(.template)
//                                .resizable()
//                                .frame(width: 20, height: 20).padding()
//                                .foregroundColor(.white)
//                                .background(.blue)
//                                .clipShape(Circle())
//                                .padding()
//                        })
//                    }
//                    .padding(.bottom, 65)
//                }
//                .sheet(isPresented: $showCreateTweet, content: {
//                    Text("Test")
//                })
//            }
//        }
//    }
//}
//
//struct Home_Previews: PreviewProvider {
//    static var previews: some View {
//        Home()
//    }
//}
