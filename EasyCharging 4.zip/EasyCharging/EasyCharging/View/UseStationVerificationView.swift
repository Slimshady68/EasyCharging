import SwiftUI
import FirebaseFirestore
import FirebaseAuth

struct UseStationVerificationView: View {
    
    @Environment(NavigationCoordinator.self) var coordinator: NavigationCoordinator
    
    var station: CustomStation
    
    @State private var userInfo: UserModel?
    @State private var paymentInfo: PaymentModel?
    @State private var carInfo: CarModel?
    
    var body: some View {
        VStack(alignment: .leading, spacing: 20) {
                Text("Please use the following code to unlock the charger and the code will expire in 2 minutes.")
                    .font(.headline)
                    .frame(maxWidth: .infinity, alignment: .center)
                    .multilineTextAlignment(.center)
            Text("\(Int.random(in: 1...9)) \(Int.random(in: 1...9)) \(Int.random(in: 1...9)) \(Int.random(in: 1...9))")
                .font(.system(size: 24, weight: .bold))
                .frame(maxWidth: .infinity, alignment: .center)
                .multilineTextAlignment(.center)
                .padding(.top, 32)
                .padding(.bottom, 32)
            
            Text("The time below will start as soon as charger is unlocked stop as the charger is locked.")
                .font(.headline)
                .frame(maxWidth: .infinity, alignment: .center)
                .multilineTextAlignment(.center)
            Button(action: {
                if let paymentData = paymentInfo {
                    coordinator.push(.stationPaymentView(station, paymentData))
                }
            }, label: {
                Capsule()
                    .frame(height: 45, alignment: .center)
                    .foregroundColor(.blue)
                    .overlay(
                    Text("On now")
                        .foregroundColor(.white)
                    )
            })
            .padding(.bottom, 4)
            .padding(.top, 24)
            Spacer()
        }
        .padding()
        .navigationTitle(station.address)
        .onAppear {
            fetchUserData()
        }
    }
    
    private func fetchUserData() {
        getAllUserData { combinedData, error in
            if let combinedData = combinedData {
                self.paymentInfo = combinedData.paymentInfo
                self.carInfo = combinedData.carInfo
            }
        }
    }
}

extension UseStationVerificationView {
    func getAllUserData(completion: @escaping (CombinedUserData?, Error?) -> Void) {
        guard let uid = Auth.auth().currentUser?.uid else {
            completion(nil, NSError(domain: "AuthError", code: -1, userInfo: [NSLocalizedDescriptionKey: "User not logged in"]))
            return
        }

        let db = Firestore.firestore()
        let userInfoRef = db.collection("UserInfo").document(uid)
        let paymentInfoRef = db.collection("PaymentInfo").document(uid)
        let carInfoRef = db.collection("CarInfo").document(uid)

        var userInfo: UserModel?
        var paymentInfo: PaymentModel?
        var carInfo: CarModel?
        var fetchError: Error?
        let dispatchGroup = DispatchGroup()

        // Fetch UserInfo data
        dispatchGroup.enter()
        userInfoRef.getDocument { document, error in
            if let document = document, document.exists, let data = document.data() {
                do {
                    let jsonData = try JSONSerialization.data(withJSONObject: data, options: [])
                    userInfo = try JSONDecoder().decode(UserModel.self, from: jsonData)
                } catch {
                    fetchError = error
                }
            } else {
                fetchError = error
            }
            dispatchGroup.leave()
        }

        // Fetch PaymentInfo data
        dispatchGroup.enter()
        paymentInfoRef.getDocument { document, error in
            if let document = document, document.exists, let data = document.data() {
                do {
                    let jsonData = try JSONSerialization.data(withJSONObject: data, options: [])
                    paymentInfo = try JSONDecoder().decode(PaymentModel.self, from: jsonData)
                } catch {
                    fetchError = error
                }
            } else {
                fetchError = error
            }
            dispatchGroup.leave()
        }

        // Fetch CarInfo data
        dispatchGroup.enter()
        carInfoRef.getDocument { document, error in
            if let document = document, document.exists, let data = document.data() {
                do {
                    let jsonData = try JSONSerialization.data(withJSONObject: data, options: [])
                    carInfo = try JSONDecoder().decode(CarModel.self, from: jsonData)
                } catch {
                    fetchError = error
                }
            } else {
                fetchError = error
            }
            dispatchGroup.leave()
        }

        // Notify when all data has been fetched
        dispatchGroup.notify(queue: .main) {
            if let error = fetchError {
                completion(nil, error)
            } else if let userInfo = userInfo, let paymentInfo = paymentInfo, let carInfo = carInfo {
                let combinedData = CombinedUserData(userInfo: userInfo, paymentInfo: paymentInfo, carInfo: carInfo)
                completion(combinedData, nil)
            } else {
                completion(nil, NSError(domain: "DataFetchingError", code: -1, userInfo: [NSLocalizedDescriptionKey: "Failed to fetch all user data"]))
            }
        }
    }
}
