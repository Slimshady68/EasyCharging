import Foundation

public struct UserAccessInfo: Equatable {
    public let accessToken: String

    public init(accessToken: String) {
        self.accessToken = accessToken
    }
}
