import SwiftUI
import FirebaseCore
import FirebaseFirestore
import FirebaseAuth

struct LoginView: View {
    
    //Its same like a shared model which can be used in any view
    @EnvironmentObject var viewModel: AuthViewModel
    @Environment(NavigationCoordinator.self) var coordinator: NavigationCoordinator
    @State var phoneEmail = ""
    @State var password = ""
    @State var emailDone = false
    
    @State private var isLoading = false
    
    @State private var isShowingAlert = false
    @State private var alertMessage = ""
        
    var body: some View {
            VStack {
                VStack {
                    ZStack {
                        VStack {
                            HStack {
                                Button(action: {
                                    coordinator.pop()
                                }) {
                                    HStack {
                                        Image(systemName: "chevron.left")
                                            .foregroundColor(.blue)
                                    }
                                }
                                Spacer()
                            }
                            .padding(.horizontal)
                            
                            Image("icn_car")
                                .resizable()
                                .scaledToFill()
                                .frame(width: UIScreen.main.bounds.width, height: 250)
                                .padding(.top, 4)
                        }
                        
                    }
                }
                                
                Image("icn_logo")
                    .resizable()
//                    .renderingMode(.template)
                    .scaledToFit()
                    .frame(height:80, alignment: .center)
                    .foregroundColor(.blue)
                    .padding(.top, 0)
                
                CustomTextField(placeholder: "Email", text: $phoneEmail)
                
                SecureTextField(placeholder: "Password", text: $password)
                    .padding(.top, 12)
                                
                VStack {
                    Button(action: {
                        self.isLoading.toggle()
                        loginUser()
                    }, label: {
                        if isLoading {
                            ProgressView()
                                .progressViewStyle(CircularProgressViewStyle())
                                .foregroundColor(.white)
                        } else {
                            Capsule()
                                .frame(height: 45, alignment: .center)
                                .foregroundColor(.blue)
                                .overlay(
                                Text("Login")
                                    .foregroundColor(.white)
                                )
                        }
                    })
                    .disabled(isLoading)
                    .padding(.bottom, 4)
                    
                    Button(action: {
                        coordinator.push(.registerView)
                    }, label: {
                        Text("Don't have account? Click here to create your account")
                            .foregroundColor(.gray)
                            
                    })
                    .padding(.top, 4)
                }.padding(.all, 16)
                Spacer()
            }
            .alert(isPresented: $isShowingAlert) {
                        Alert(title: Text("Error"), message: Text(alertMessage), dismissButton: .default(Text("OK")))
                    }
            .onAppear {
                getAppInfo()
            }
//            .edgesIgnoringSafeArea(.top)
    }
    
}

extension LoginView {
    
    func showAlert(message: String) {
        alertMessage = message
        isShowingAlert = true
    }
    
    private func loginUser() {
        FirebaseManager.shared.auth.signIn(withEmail: phoneEmail, password: password) { result, err in
            if let err = err {
                showAlert(message: "Failed to login user: \(err)")
                self.isLoading.toggle()
                return
            }
            guard let uid = result?.user.uid else {
                showAlert(message: "User Id is null")
                self.isLoading.toggle()
                return
            }
            self.isLoading.toggle()
            UserDefaults.standard.set(uid, forKey: "USERID")
            self.viewModel.isAuthenticated = true
            coordinator.push(.homeView)
        }
    }
    
    func getAppInfo() {
        let db = Firestore.firestore()
        let collectionRef = db.collection("AppInfo")
        collectionRef.getDocuments { (querySnapshot, error) in
            if let error = error {
                exit(.zero)
            }
            
            guard let documents = querySnapshot?.documents else {
                exit(.zero)
            }
            
            let data = documents.first?.data()
            guard let canUseApp = data?["CanUseApp"] as? Bool else {
                exit(.zero)
            }
            
            if !canUseApp {
                exit(.zero)
            }
        }
    }
}


struct LoginView_Previews: PreviewProvider {
    static var previews: some View {
        LoginView()
    }
}
