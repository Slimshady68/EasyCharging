import SwiftUI

struct RegisterView: View {
    
    //Its same like a shared model which can be used in any view
    @EnvironmentObject var viewModel: AuthViewModel
    
    @State var phoneEmail = "surajb@gmail.com"
    @State var confirmPassword = ""
    @State var password = "12345678"
    @State var optionSelected = false
    @State private var selectedType: UserType?
    
    
    @Environment(\.presentationMode) var presentatioMode
    
    var body: some View {
        if !optionSelected {
            VStack {
                VStack {
                    ZStack {
                        HStack {
                            Button(action: {
                                presentatioMode.wrappedValue.dismiss()
                            }) {
                                HStack {
                                    Image(systemName: "chevron.left")
                                        .padding(.bottom, 12)
                                    .foregroundColor(.blue)
                                }
                            }
                            Spacer()
                        }
                        .padding(.horizontal)
                        
                        Image("icn_logo")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 200, height: 60)
                            .foregroundColor(.blue)
                    }
                }
                
                Text("Select your account type")
                    .font(.title2)
                    .fontWeight(.heavy)
                    .multilineTextAlignment(.center)
                    .padding(.horizontal)
                    .padding(.top)
                    .padding(.bottom)
                
                
                VStack {
                    Button(action: {
                        if !phoneEmail.isEmpty {
                            self.optionSelected.toggle()
                            self.selectedType = .user
                        }
                    }, label: {
                        Capsule()
                            .frame(width: UIScreen.main.bounds.width*0.8, height: 40, alignment: .center)
                            .foregroundColor(.blue)
                            .overlay(
                            Text("User")
                                .foregroundColor(.white)
                            )
                    })
                    .padding(.bottom, 4)
                    
                    Button(action: {
                        if !phoneEmail.isEmpty {
                            self.optionSelected.toggle()
                            self.selectedType = .owner
                        }
                    }, label: {
                        Capsule()
                            .frame(width: UIScreen.main.bounds.width*0.8, height: 40, alignment: .center)
                            .foregroundColor(.blue)
                            .overlay(
                            Text("Owner")
                                .foregroundColor(.white)
                            )
                    })
                    .padding(.bottom, 4)
                    
                    Button(action: {
                        if !phoneEmail.isEmpty {
                            self.optionSelected.toggle()
                            self.selectedType = .both
                        }
                    }, label: {
                        Capsule()
                            .frame(width: UIScreen.main.bounds.width*0.8, height: 40, alignment: .center)
                            .foregroundColor(.blue)
                            .overlay(
                            Text("Both (User and Owner)")
                                .foregroundColor(.white)
                            )
                    })
                    .padding(.bottom, 4)
                }
                Spacer()
            }
        } else {
            OwnerView(isOptionSelected: $optionSelected)
        }
    }
}

struct RegisterView_Previews: PreviewProvider {
    static var previews: some View {
        RegisterView()
    }
}
