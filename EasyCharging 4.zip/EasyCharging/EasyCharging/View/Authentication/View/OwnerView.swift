import Foundation
import FirebaseAuth
import FirebaseFirestore
import CoreLocation
import SwiftUI
import CommonCrypto
import Foundation

struct OwnerView: View {
    
    @Binding var isOptionSelected: Bool
    @State var isUserSelected = true
    @State var isPaymentMethodSelected = false
    @State var isStationSelected = false
    
    @State var fullName = ""
    @State var email = ""
    @State var phone = ""
    @State var address = ""
    @State var password = ""
    @State var cardNumber = ""
    @State var holderName = ""
    @State var expiryDate = ""
    @State var cvv = ""
    @State var carType = ""
    @State var chargerType = ""
    
    @State private var isLoading = false
    
    @State private var isShowingAlert = false
    @State private var alertMessage = ""
    
    @Environment(\.presentationMode) var presentatioMode
    
    var body: some View {
        if isUserSelected {
            VStack{
                VStack {
                    ZStack {
                        HStack {
                            Button(action: {
                                self.isOptionSelected = false
                            }) {
                                HStack {
                                    Image(systemName: "chevron.left")
                                        .padding(.bottom, 12)
                                        .foregroundColor(.blue)
                                }
                            }
                            Spacer()
                        }
                        .padding(.horizontal)
                        
                        Image("icn_logo")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 200, height: 60)
                            .foregroundColor(.blue)
                    }
                }
                ScrollView(.vertical){
                    VStack(spacing: 12){
                        Text("User Detail")
                            .font(.system(size: 18.0))
                            .fontWeight(.bold)
                        
                        CustomTextField(placeholder: "Full Name", text: $fullName)
                        
                        CustomTextField(placeholder: "Email", text: $email)
                        
                        CustomTextField(placeholder: "Phone Number", text: $phone)
                        
                        CustomTextField(placeholder: "Address", text: $address)
                        
                        SecureTextField(placeholder: "Password", text: $password)
                        
                        Button(action: {
                            self.isUserSelected = false
                            self.isPaymentMethodSelected = true
                        }, label: {
                            Capsule()
                                .frame(height: 45, alignment: .center)
                                .foregroundColor(fullName == "" || email == "" || phone == "" || address == "" || password == "" ? .gray : .blue)
                                .overlay(
                                    Text("Next")
                                        .foregroundColor(.white)
                                )
                        })
                        .disabled(fullName == "" || email == "" || phone == "" || address == "" || password == "")
                        .padding()
                    }
                }
            }
        } else if isPaymentMethodSelected {
            VStack{
                VStack {
                    ZStack {
                        HStack {
                            Button(action: {
                                self.isUserSelected = true
                                self.isStationSelected = false
                                self.isPaymentMethodSelected = false
                            }) {
                                HStack {
                                    Image(systemName: "chevron.left")
                                        .padding(.bottom, 12)
                                        .foregroundColor(.blue)
                                }
                            }
                            Spacer()
                        }
                        .padding(.horizontal)
                        
                        Image("icn_logo")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 200, height: 60)
                            .foregroundColor(.blue)
                    }
                }
                ScrollView(.vertical){
                    VStack(spacing: 12){
                        Text("Payment Method Detail")
                            .font(.system(size: 18.0))
                            .fontWeight(.bold)
                        
                        CustomTextField(placeholder: "Card Number:", text: $cardNumber)
                        
                        CustomTextField(placeholder: "Holder Name:", text: $holderName)
                        
                        CustomTextField(placeholder: "Expiry Date:", text: $expiryDate)
                        
                        CustomTextField(placeholder: "CVV:", text: $cvv)
                        
                        
                        Button(action: {
                            self.isStationSelected = true
                            self.isUserSelected = false
                            self.isPaymentMethodSelected = false
                        }, label: {
                            Capsule()
                                .frame(height: 45, alignment: .center)
                                .foregroundColor(cardNumber == "" || holderName == "" || expiryDate == "" || cvv == "" ? .gray : .blue)
                                .overlay(
                                    Text("Next")
                                        .foregroundColor(.white)
                                )
                        })
                        .disabled(cardNumber == "" || holderName == "" || expiryDate == "" || cvv == "")
                        .padding()
                    }
                }
            }
        } else if isStationSelected {
            VStack{
                VStack {
                    ZStack {
                        HStack {
                            Button(action: {
                                self.isUserSelected = false
                                self.isStationSelected = false
                                self.isPaymentMethodSelected = true
                            }) {
                                HStack {
                                    Image(systemName: "chevron.left")
                                        .padding(.bottom, 12)
                                        .foregroundColor(.blue)
                                }
                            }
                            Spacer()
                        }
                        .padding(.horizontal)
                        
                        Image("icn_logo")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 200, height: 60)
                            .foregroundColor(.blue)
                    }
                }
                ScrollView(.vertical){
                    VStack(spacing: 12){
                        Text("Car and Charger Type Detail")
                            .font(.system(size: 18.0))
                            .fontWeight(.bold)
                        
                        CustomTextField(placeholder: "Car Type:", text: $carType)
                        
                        CustomTextField(placeholder: "Charger Type:", text: $chargerType)
                        
                        Spacer()
                        
                        Button(action: {
                            if fullName != "" && email != "" && password != "" {
                                self.isLoading.toggle()
                                self.createNewAccount()
                            } else {
                                showAlert(message: "Field cannot be blank")
                            }
                        }, label: {
                            if isLoading {
                                ProgressView()
                                    .progressViewStyle(CircularProgressViewStyle())
                                    .foregroundColor(.white)
                            } else {
                                Capsule()
                                    .frame(height: 45, alignment: .center)
                                    .foregroundColor(carType == "" || chargerType == "" ? .gray : .blue)
                                    .overlay(
                                        Text("Submit")
                                            .foregroundColor(.white)
                                    )
                            }
                        })
                        .disabled(carType == "" || chargerType == "")
                        .padding(.leading)
                        .padding(.trailing)
                        .padding(.bottom)
                    }
                }
            }
            .alert(isPresented: $isShowingAlert) {
                        Alert(title: Text("Error"), message: Text(alertMessage), dismissButton: .default(Text("OK")))
                    }
        }
    }
}

extension OwnerView {
    func showAlert(message: String) {
        alertMessage = message
        isShowingAlert = true
    }
    //Create User
    private func createNewAccount() {
        FirebaseManager.shared.auth.createUser(withEmail: email, password: password) { result, err in
            if let err = err {
                showAlert(message: "Failed to create user: \(err)")
                self.isLoading.toggle()
                return
            }
            
            // User created successfully
                guard let uid = result?.user.uid else {
                    showAlert(message: "User ID is null")
                    self.isLoading.toggle()
                    return
                }
            
            saveUserData(uid: uid) { error in
                if let error = error {
                    showAlert(message: "Error saving user data: \(error)")
                    self.isLoading.toggle()
                    
                } else {
                    savePaymentData(uid: uid) { error in
                        if let error = error {
                            showAlert(message: "Error saving payment data: \(error)")
                            self.isLoading.toggle()
                        } else {
                            saveCarData(uid: uid) { error in
                                if let error = error {
                                    showAlert(message: "Error saving car data: \(error)")
                                    self.isLoading.toggle()
                                } else {
                                    // Dismiss presentation mode here
                                    self.isLoading.toggle()
                                    self.presentatioMode.wrappedValue.dismiss()
                                }
                            }
                        }
                    }
                }
            }
            
                
        }
    }
    
    //Save userData
    func saveUserData(uid: String, completion: @escaping (Error?) -> Void) {
        let db = Firestore.firestore()
        let userData: [String: Any] = [
            "fullname": fullName,
            "email": email,
            "phone": phone,
            "address": address
        ]
        
        db.collection("UserInfo").document(uid).setData(userData) { error in
            completion(error)
        }
    }
    
    //Save paymentData
    func savePaymentData(uid: String, completion: @escaping (Error?) -> Void) {
        let db = Firestore.firestore()
        
        let paymentData: [String: Any] = [
            "card_number": cardNumber,
            "holder_name": holderName,
            "expiry_date": expiryDate,
            "cvv": cvv
        ]
        
        db.collection("PaymentInfo").document(uid).setData(paymentData) { error in
            completion(error)
        }
    }
    
    //Save CarData
    func saveCarData(uid: String, completion: @escaping (Error?) -> Void) {
        let db = Firestore.firestore()
        
        let paymentData: [String: Any] = [
            "car_type": carType,
            "charger_type": chargerType
        ]
        
        db.collection("CarInfo").document(uid).setData(paymentData) { error in
            completion(error)
        }
    }
    
    //Delete station
    func deleteStation(documentId: String) {
        let db = Firestore.firestore()
        let collectionRef = db.collection("CustomStations")
        let document = collectionRef.document(documentId)
        document.delete { error in
            if let error = error {
                print("Error deleting document: \(error)")
            } else {
                print("Document successfully deleted")
            }
        }
    }
}
    
struct CustomStation: Identifiable, Hashable {
    let id: String
    let address: String
    let charger: String
    let phone: String
    let level: String
    let rate: String
    let latitude: Double
    let longitude: Double
    var distance: Int?
}

struct FavoriteStation {
    let id: String
    let name: String
    let status: String
    let access: String
    let level: String
}


//Station Info activity left
