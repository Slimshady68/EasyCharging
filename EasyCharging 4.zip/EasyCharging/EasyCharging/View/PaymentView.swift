import SwiftUI

struct PaymentView: View {
    @Environment(NavigationCoordinator.self) var coordinator: NavigationCoordinator
    
    var station: CustomStation
    var paymentModel: PaymentModel
    
    @State private var showAlert = false
    
    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            Text("Thank you for using the station at \(station.address) and the total time of charging is:")
                .font(.headline)
                .frame(maxWidth: .infinity, alignment: .center)
                .multilineTextAlignment(.center)
            Text("2:30:00")
                .font(.system(size: 24, weight: .bold))
                .frame(maxWidth: .infinity, alignment: .center)
                .multilineTextAlignment(.center)
                .padding(.top, 48)
                .padding(.bottom, 48)
            
            Text("The cost of this charge is:")
                .font(.headline)
                .frame(maxWidth: .infinity, alignment: .center)
                .multilineTextAlignment(.center)
            Text("Time: 2.30*3=6.9")
                .font(.headline)
                .frame(maxWidth: .infinity, alignment: .center)
                .multilineTextAlignment(.center)
            Text("Service: 0.06")
                .font(.headline)
                .frame(maxWidth: .infinity, alignment: .center)
                .multilineTextAlignment(.center)
            Text("Total: $8.5")
                .font(.headline)
                .frame(maxWidth: .infinity, alignment: .center)
                .multilineTextAlignment(.center)
            Button(action: {
                showAlert = true
            }, label: {
                Capsule()
                    .frame(height: 45, alignment: .center)
                    .foregroundColor(.blue)
                    .overlay(
                        Text("Pay $8.5")
                            .foregroundColor(.white)
                    )
            })
            .padding(.bottom, 4)
            .padding(.top, 48)
            .alert(isPresented: $showAlert) {
                Alert(
                    title: Text("Payment Successful"),
                    message: Text("$8.5 is deducted from your card \(paymentModel.cardNumber), Thankyou for using easy charging"),
                    dismissButton: .default(Text("OK"), action: {
                        coordinator.toHome()
                    })
                )
            }
            Spacer()
        }
        .padding()
        .navigationTitle(station.address)
    }
}
