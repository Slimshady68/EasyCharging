import SwiftUI
import FirebaseFirestore
import FirebaseAuth
import MapKit

struct MapView: View {
    @State private var isLoading = false
    @State private var stations = [CustomStation]()
    @State private var filteredStations = [CustomStation]()
    @State private var nearestStation: CustomStation?
    
    @Environment(NavigationCoordinator.self) var coordinator: NavigationCoordinator
    @StateObject var manager = LocationManager()
    @State var searchText = ""
    @State var isEditing = false
    @State private var selectedStation: CustomStation?
    @State private var showingAlert = false
    @State private var lastRegion: MKCoordinateRegion?
    @State private var locationTimer: Timer?

    var body: some View {
        VStack {
            if isLoading {
                ProgressView("Loading...")
                    .progressViewStyle(CircularProgressViewStyle())
                    .padding()
            } else {
                VStack {
                    Text("Home")
                        .font(.system(size: 18, weight: .semibold))
                    HStack(alignment: .center, spacing: 4) {
                        CustomTextField(placeholder: "Search", text: $searchText, onEditingChanged: { isEditing in
                            self.isEditing = isEditing
                            filterStations()
                        }, onCommit: {
                            filterStations()
                        })
                        Button(action: {
                            coordinator.push(.filterView)
                        }) {
                            Image("filter")
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .frame(width: 20, height: 20)
                        }
                        .padding(.top)
                        Spacer(minLength: 4)
                        Button(action: {
                            coordinator.push(.favoriteView)
                        }) {
                            Image("icn_fav")
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .frame(width: 20, height: 20)
                        }
                        .padding(.top)
                    }
                    .padding(.trailing)
                    
                    if isEditing && !searchText.isEmpty {
                        List(filteredStations) { station in
                            HStack {
                                VStack(alignment: .leading) {
                                    Text(station.address)
                                        .font(.headline)
                                    Text("Charger: \(station.charger)")
                                        .font(.subheadline)
                                    Text("Level: \(station.level)")
                                        .font(.subheadline)
                                    Text("Rate: \(station.rate)")
                                        .font(.subheadline)
                                }
                                Spacer()
                                Button(action: {
                                    manager.region = MKCoordinateRegion(
                                                                center: CLLocationCoordinate2D(latitude: station.latitude, longitude: station.longitude),
                                                                span: MKCoordinateSpan(latitudeDelta: 0.05, longitudeDelta: 0.05)
                                                            )
                                    searchText = ""
                                    isEditing = false
//                                    self.coordinator.push(.stationDetail(station))
                                }) {
                                    Image(systemName: "info.circle")
                                        .resizable()
                                        .frame(width: 20, height: 20)
                                }
                            }
                        }
                        .listStyle(PlainListStyle())
                    } else {
                        ZStack {
                            Map(coordinateRegion: $manager.region, annotationItems: filteredStations) { station in
                                MapAnnotation(coordinate: CLLocationCoordinate2D(latitude: station.latitude, longitude: station.longitude)) {
                                    Button(action: {
                                        selectedStation = station
                                        showingAlert = true
                                    }) {
                                        Image(systemName: "mappin.circle.fill")
                                            .resizable()
                                            .foregroundColor(.red)
                                            .frame(width: 30, height: 30)
                                    }
                                }
                            }
                            .edgesIgnoringSafeArea(.bottom)
                            
                            if let nearestStation = nearestStation {
                                VStack {
                                    NearestStationView(station: nearestStation, coordinator: coordinator)
                                    Spacer()
                                }
                            }
                        }
                        .alert(isPresented: $showingAlert) {
                            Alert(
                                title: Text(selectedStation?.address ?? "No Address"),
                                message: Text("Charger: \(selectedStation?.charger ?? "N/A")\nLevel: \(selectedStation?.level ?? "N/A")\nRate: \(selectedStation?.rate ?? "N/A")"),
                                primaryButton: .default(Text("View Detail")) {
                                    if let station = selectedStation {
                                        coordinator.push(.stationDetail(station))
                                    }
                                },
                                secondaryButton: .cancel(Text("Close")) {
                                    selectedStation = nil
                                    showingAlert = false
                                }
                            )
                        }
                    }
                }
            }
        }
        .frame(minWidth: 360, minHeight: 400)
        .padding(.bottom)
        .onAppear {
            getAllStations()
            startLocationTimer()
        }
        .onDisappear {
            locationTimer?.invalidate()
        }
    }
    
    func filterStations() {
        if searchText.isEmpty {
            filteredStations = stations
        } else {
            filteredStations = stations.filter {
                $0.address.localizedCaseInsensitiveContains(searchText) ||
                $0.charger.localizedCaseInsensitiveContains(searchText) ||
                $0.level.localizedCaseInsensitiveContains(searchText) ||
                $0.rate.localizedCaseInsensitiveContains(searchText)
            }
        }
    }
    
    func findNearestStation() {
        let currentCenter = manager.myRegion.center
        let currentLocation = CLLocation(latitude: currentCenter.latitude, longitude: currentCenter.longitude)
        
        nearestStation = stations.min(by: { station1, station2 in
            let location1 = CLLocation(latitude: station1.latitude, longitude: station1.longitude)
            let location2 = CLLocation(latitude: station2.latitude, longitude: station2.longitude)
            return currentLocation.distance(from: location1) < currentLocation.distance(from: location2)
        })
        
        // Update distances for all stations
                for index in stations.indices {
                    let stationLocation = CLLocation(latitude: stations[index].latitude, longitude: stations[index].longitude)
                    let distanceInMeters = currentLocation.distance(from: stationLocation)
                    let distanceInMiles = (distanceInMeters * 0.000621371).rounded() // Convert meters to miles and round to nearest whole number
                    stations[index].distance = Int(distanceInMiles)
                }
    }
    
    func startLocationTimer() {
        locationTimer = Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) { _ in
            findNearestStation()
        }
    }
}

extension MapView {
    func getAllStations() {
        isLoading = true
        var customStations = [CustomStation]()
        let db = Firestore.firestore()
        let auth = Auth.auth()
        guard let currentUser = auth.currentUser else {
            print("No current user")
            isLoading = false
            return
        }
        
        let collectionRef = db.collection("StationInfo")
        
        collectionRef.getDocuments { (querySnapshot, error) in
            if let error = error {
                print("Error getting documents: \(error)")
                isLoading = false
                return
            }
            
            guard let documents = querySnapshot?.documents else {
                print("No documents")
                isLoading = false
                return
            }
            
            for document in documents {
                let data = document.data()
                guard let address = data["Address"] as? String,
                      let charger = data["Charger"] as? String,
                      let level = data["Level"] as? String,
                      let rate = data["Rate"] as? String,
                      let phone = data["Phone"] as? String,
                      let latitude = data["Latitude"] as? Double,
                      let longitude = data["Longitude"] as? Double,
                      let id = data["id"] as? String else {
                    continue
                }
                let customStation = CustomStation(id: id, address: address, charger: charger, phone: phone, level: level, rate: rate, latitude: latitude, longitude: longitude)
                customStations.append(customStation)
            }
            
            // Update the state object with fetched data
            DispatchQueue.main.async {
                isLoading = false
                self.stations = customStations
                self.filteredStations = customStations
                self.findNearestStation()
            }
        }
    }
}

struct NearestStationView: View {
    var station: CustomStation
    var coordinator: NavigationCoordinator
    
    var body: some View {
        VStack(alignment: .leading) {
            HStack {
                VStack(alignment: .leading) {
                    Text(station.address)
                        .font(.subheadline)
                    Text("Charger: \(station.charger)")
                        .font(.subheadline)
                    Text("Level: \(station.level)")
                        .font(.subheadline)
                    Text("Distance: \(station.distance ?? 0) Miles")
                        .font(.subheadline)
                }
                Spacer()
                VStack(alignment: .leading) {
                    Button(action: {
                        coordinator.push(.stationDetail(station))
                    }) {
                        Text("Use Nearest Station")
                            .font(.system(size: 14, weight: .semibold))
                            .padding(.horizontal)
                            .padding(.vertical, 6)
                            .background(Color.blue)
                            .foregroundColor(.white)
                            .cornerRadius(5)
                    }
                }
            }
        }
        .padding()
        .background(Color.white)
    }
}
