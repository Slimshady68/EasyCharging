import Foundation

struct UserModel: Codable {
    var fullname: String
    var email: String
    var phone: String
    var address: String
}

struct PaymentModel: Codable, Hashable {
    var cardNumber: String
    var holderName: String
    var expiryDate: String
    var cvv: String
    
    enum CodingKeys: String, CodingKey {
        case cardNumber = "card_number"
        case holderName = "holder_name"
        case expiryDate = "expiry_date"
        case cvv = "cvv"
    }
}

struct CarModel: Codable {
    var carType: String
    var chargerType: String
    
    enum CodingKeys: String, CodingKey {
        case carType = "car_type"
        case chargerType = "charger_type"
    }
}

struct CombinedUserData: Codable {
    var userInfo: UserModel
    var paymentInfo: PaymentModel
    var carInfo: CarModel
}
