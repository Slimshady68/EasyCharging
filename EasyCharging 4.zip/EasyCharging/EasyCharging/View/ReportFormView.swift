import SwiftUI
import FirebaseAuth
import FirebaseFirestore

struct ReportFormView: View {
    @Environment(NavigationCoordinator.self) var coordinator: NavigationCoordinator
    @State private var isLoading = false
    @State private var isShowingAlert = false
    @State private var alertMessage = ""
    
    var station: CustomStation
    
    @State private var selectedError = "Naming Error"
        let errorType = ["Naming Error", "Payment Error", "Location Error", "App not function", "Station not appear in map"]
    
    @State private var description: String = ""
    
    var body: some View {
        VStack(alignment: .center, spacing: 20) {
            Text(station.address)
                .font(.headline)
                .frame(maxWidth: .infinity, alignment: .leading)
                .multilineTextAlignment(.leading)
            Text("Report Time: \(getFormattedDate())")
                .font(.headline)
                .frame(maxWidth: .infinity, alignment: .leading)
            HStack {
                            Text("Error Type:")
                                .font(.headline)
                            Spacer()
                            Picker("Select Time", selection: $selectedError) {
                                ForEach(errorType, id: \.self) { time in
                                    Text(time)
                                }
                            }
                            .pickerStyle(MenuPickerStyle()) // Optional: Use menu style for better look
                        }
            TextEditor(text: $description)
                .padding(4)
                            .frame(height: 100)
                            .background(Color.white)
                            .overlay(
                                                RoundedRectangle(cornerRadius: 8)
                                                    .stroke(Color.gray, lineWidth: 1)
                                            )
            Button(action: {
                self.isLoading.toggle()
                submitReport(stationId: station.id)
            }, label: {
                if isLoading {
                    ProgressView()
                        .progressViewStyle(CircularProgressViewStyle())
                        .foregroundColor(.white)
                } else {
                    Capsule()
                        .frame(height: 45, alignment: .center)
                        .foregroundColor(.blue)
                        .overlay(
                            Text("Submit")
                                .foregroundColor(.white)
                        )
                }
            })
            .disabled(isLoading)
            .padding(.bottom, 4)
            Spacer()
        }
        .padding()
        .navigationTitle("Report")
        .alert(isPresented: $isShowingAlert) {
                    Alert(title: Text("Error"), message: Text(alertMessage), dismissButton: .default(Text("OK")))
                }
    }
}

extension ReportFormView {
    
    func getFormattedDate() -> String {
            let date = Date() // or use a specific date if needed
            
            let formatter = DateFormatter()
            formatter.dateFormat = "yyyy-MM-dd h:mm a"
            return formatter.string(from: date)
        }
    
    func showAlert(message: String) {
        alertMessage = message
        isShowingAlert = true
    }
    
    //Report sumbit
    func submitReport(stationId: String) {
        let auth = Auth.auth()
        let db = Firestore.firestore()
        
        guard let currentUser = auth.currentUser else {
            showAlert(message: "Authentication Error")
            self.isLoading.toggle()
            return
        }
        
        let collectionRef = db.collection("StationReports")
        
        let newReport: [String: Any] = [
            "UID": currentUser.uid,
            "reportType": selectedError,
            "reportDesc": description,
            "stationId": stationId // Assuming you have stationId declared somewhere
        ]
        
        collectionRef.addDocument(data: newReport) { error in
            if let error = error {
                showAlert(message: "Error sending reports")
                self.isLoading.toggle()
            } else {
                coordinator.pop()
            }
        }
    }
}
