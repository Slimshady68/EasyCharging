import SwiftUI
import FirebaseFirestore
import FirebaseAuth

struct UserProfileView: View {
    @Environment(NavigationCoordinator.self) var coordinator: NavigationCoordinator
    
    @State private var userInfo: UserModel?
    @State private var paymentInfo: PaymentModel?
    @State private var carInfo: CarModel?
    @State private var fetchError: Error?
    
    var body: some View {
            VStack(spacing: 20) {
                Text("Profile")
                    .font(.system(size: 18, weight: .semibold))
                
                if let userInfo = userInfo, let paymentInfo = paymentInfo, let carInfo = carInfo {
                    Group {
                        profileRow(title: "Name:", value: userInfo.fullname)
                        profileRow(title: "Email:", value: userInfo.email)
                        profileRow(title: "Phone Number:", value: userInfo.phone)
                        profileRow(title: "Address:", value: userInfo.address)
                        profileRow(title: "Card Number:", value: paymentInfo.cardNumber)
                        profileRow(title: "Charger Type:", value: carInfo.chargerType)
                    }
                } else if let error = fetchError {
                    Text("Failed to load profile data: \(error.localizedDescription)")
                        .foregroundColor(.red)
                } else {
                    Text("Loading...")
                }

                Button(action: {
                    coordinator.push(.myStation)
                }) {
                    Capsule()
                        .frame(height: 45, alignment: .center)
                        .foregroundColor(.blue)
                        .overlay(
                            Text("View Charge Station")
                                .foregroundColor(.white)
                        )
                }
                .padding(.top)
                Spacer()
            }
            .padding()
            .navigationTitle("User Profile")
            .onAppear {
                fetchUserData()
            }
        }

        private func profileRow(title: String, value: String) -> some View {
            HStack {
                Text(title)
                    .font(.headline)
                Spacer()
                Text(value)
                    .font(.subheadline)
                    .foregroundColor(.gray)
            }
        }

        private func fetchUserData() {
            getAllUserData { combinedData, error in
                if let combinedData = combinedData {
                    self.userInfo = combinedData.userInfo
                    self.paymentInfo = combinedData.paymentInfo
                    self.carInfo = combinedData.carInfo
                } else {
                    self.fetchError = error
                }
            }
        }
    }

    extension UserProfileView {
        func getAllUserData(completion: @escaping (CombinedUserData?, Error?) -> Void) {
            guard let uid = Auth.auth().currentUser?.uid else {
                completion(nil, NSError(domain: "AuthError", code: -1, userInfo: [NSLocalizedDescriptionKey: "User not logged in"]))
                return
            }

            let db = Firestore.firestore()
            let userInfoRef = db.collection("UserInfo").document(uid)
            let paymentInfoRef = db.collection("PaymentInfo").document(uid)
            let carInfoRef = db.collection("CarInfo").document(uid)

            var userInfo: UserModel?
            var paymentInfo: PaymentModel?
            var carInfo: CarModel?
            var fetchError: Error?
            let dispatchGroup = DispatchGroup()

            // Fetch UserInfo data
            dispatchGroup.enter()
            userInfoRef.getDocument { document, error in
                if let document = document, document.exists, let data = document.data() {
                    do {
                        let jsonData = try JSONSerialization.data(withJSONObject: data, options: [])
                        userInfo = try JSONDecoder().decode(UserModel.self, from: jsonData)
                    } catch {
                        fetchError = error
                    }
                } else {
                    fetchError = error
                }
                dispatchGroup.leave()
            }

            // Fetch PaymentInfo data
            dispatchGroup.enter()
            paymentInfoRef.getDocument { document, error in
                if let document = document, document.exists, let data = document.data() {
                    do {
                        let jsonData = try JSONSerialization.data(withJSONObject: data, options: [])
                        paymentInfo = try JSONDecoder().decode(PaymentModel.self, from: jsonData)
                    } catch {
                        fetchError = error
                    }
                } else {
                    fetchError = error
                }
                dispatchGroup.leave()
            }

            // Fetch CarInfo data
            dispatchGroup.enter()
            carInfoRef.getDocument { document, error in
                if let document = document, document.exists, let data = document.data() {
                    do {
                        let jsonData = try JSONSerialization.data(withJSONObject: data, options: [])
                        carInfo = try JSONDecoder().decode(CarModel.self, from: jsonData)
                    } catch {
                        fetchError = error
                    }
                } else {
                    fetchError = error
                }
                dispatchGroup.leave()
            }

            // Notify when all data has been fetched
            dispatchGroup.notify(queue: .main) {
                if let error = fetchError {
                    completion(nil, error)
                } else if let userInfo = userInfo, let paymentInfo = paymentInfo, let carInfo = carInfo {
                    let combinedData = CombinedUserData(userInfo: userInfo, paymentInfo: paymentInfo, carInfo: carInfo)
                    completion(combinedData, nil)
                } else {
                    completion(nil, NSError(domain: "DataFetchingError", code: -1, userInfo: [NSLocalizedDescriptionKey: "Failed to fetch all user data"]))
                }
            }
        }
    }


struct UserProfileView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView {
            UserProfileView()
        }
    }
}
