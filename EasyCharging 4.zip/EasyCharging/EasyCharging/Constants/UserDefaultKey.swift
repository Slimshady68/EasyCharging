import Foundation

enum UserDefaultKeys: String {
case ACCESS_TOKEN = "access_token"
}
