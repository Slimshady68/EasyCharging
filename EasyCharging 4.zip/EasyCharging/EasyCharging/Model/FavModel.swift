//
//  FavModel.swift
//  EasyCharging
//

import SwiftUI
import Foundation

struct FavModel: Decodable , Identifiable {
    let id: Int
    let headerTitle : String
    let status: String
    let access: String
    let level: String
}

struct StationModel: Decodable , Identifiable {
    let id: Int
    let headerTitle : String
    let status: String
    let access: String
    let level: String
    let price: String
}

struct MockData {
    
    static let sampleChargeData = FavModel(id: 001, headerTitle: "8201 Tampa Avenue", status: "Functional", access: "public", level: "Level2")
                                           
    static let sampleStationData = StationModel(id: 001, headerTitle: "8201 Tampa Avenue", status: "Functional", access: "public", level: "Level2", price: "10")
                                           
    
    static let chargerdata = [sampleChargeData,sampleChargeData,sampleChargeData,sampleChargeData]
    
    static let stationdata = [sampleStationData,sampleStationData,sampleStationData,sampleStationData]
    
    
}
